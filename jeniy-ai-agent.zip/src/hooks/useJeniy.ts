import { useState, useEffect, useCallback, useRef } from 'react';
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { auth, db, googleProvider, signInWithPopup, signOut, signInWithEmailAndPassword, doc, getDoc, setDoc, updateDoc, onSnapshot, serverTimestamp, getDocFromServer, collection, addDoc, deleteDoc, query, where, orderBy, getDocs, writeBatch } from '../firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

interface CustomCommand {
  id: string;
  uid: string;
  label: string;
  command: string;
  createdAt: any;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ... (tool definitions remain the same)

const openUrlTool: FunctionDeclaration = {
  name: "open_url",
  description: "Opens a specific URL in a new browser tab.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: "The full URL to open (e.g., https://www.google.com)",
      },
    },
    required: ["url"],
  },
};

const searchGoogleTool: FunctionDeclaration = {
  name: "search_google",
  description: "Performs a Google search for the given query.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: "The search query.",
      },
    },
    required: ["query"],
  },
};

const makeCallTool: FunctionDeclaration = {
  name: "make_call",
  description: "Simulates making a phone call to a specific number or contact name.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      target: {
        type: Type.STRING,
        description: "The phone number or contact name to call.",
      },
    },
    required: ["target"],
  },
};

const videoCallTool: FunctionDeclaration = {
  name: "video_call",
  description: "Initiates a video call to a specific contact or number using the device camera and microphone.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      target: {
        type: Type.STRING,
        description: "The name or number to call.",
      },
    },
    required: ["target"],
  },
};

const receiveCallTool: FunctionDeclaration = {
  name: "receive_call",
  description: "Simulates receiving an incoming call from a specific contact or number.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      from: {
        type: Type.STRING,
        description: "The name or number of the caller.",
      },
    },
    required: ["from"],
  },
};

const receiveVideoCallTool: FunctionDeclaration = {
  name: "receive_video_call",
  description: "Simulates receiving an incoming video call from a specific contact or number.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      from: {
        type: Type.STRING,
        description: "The name or number of the caller.",
      },
    },
    required: ["from"],
  },
};

const checkBalanceTool: FunctionDeclaration = {
  name: "check_balance",
  description: "Simulates checking the mobile account balance (USSD *121#).",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const checkOffersTool: FunctionDeclaration = {
  name: "check_offers",
  description: "Simulates checking available mobile offers (USSD *121*1#).",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const manageGalleryTool: FunctionDeclaration = {
  name: "manage_gallery",
  description: "Accesses the virtual mobile gallery to view, open, or delete photos.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        enum: ["list", "open", "delete"],
        description: "The action to perform in the gallery.",
      },
      photoId: {
        type: Type.STRING,
        description: "The ID of the photo to open or delete (required for 'open' and 'delete').",
      },
    },
    required: ["action"],
  },
};

const searchYoutubeTool: FunctionDeclaration = {
  name: "search_youtube",
  description: "Performs a YouTube search for the given query.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: "The search query for YouTube.",
      },
    },
    required: ["query"],
  },
};

const whatsappSendTool: FunctionDeclaration = {
  name: "whatsapp_send",
  description: "Prepares a WhatsApp message to a specific contact or number. If a name is provided, Jeniy will look it up in the saved contacts.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      phone: {
        type: Type.STRING,
        description: "The phone number in international format (e.g., +88017...). Optional if 'name' is provided.",
      },
      name: {
        type: Type.STRING,
        description: "The name of the contact to look up in saved contacts.",
      },
      message: {
        type: Type.STRING,
        description: "The message content.",
      },
    },
    required: ["message"],
  },
};

const addContactTool: FunctionDeclaration = {
  name: "add_contact",
  description: "Saves a new contact (name and phone number) to Jeniy's memory.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      name: {
        type: Type.STRING,
        description: "The contact's name.",
      },
      phone: {
        type: Type.STRING,
        description: "The contact's phone number in international format.",
      },
    },
    required: ["name", "phone"],
  },
};

const addTaskTool: FunctionDeclaration = {
  name: "add_task",
  description: "Creates a new task or reminder.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: "The task description or title.",
      },
      dueDate: {
        type: Type.STRING,
        description: "Optional due date or reminder time (e.g., 'tomorrow at 10am', '2024-05-01').",
      },
      priority: {
        type: Type.STRING,
        enum: ["low", "medium", "high"],
        description: "Task priority.",
      },
    },
    required: ["title"],
  },
};

const updateTaskTool: FunctionDeclaration = {
  name: "update_task",
  description: "Updates an existing task's status or details.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      taskId: {
        type: Type.STRING,
        description: "The unique ID of the task to update.",
      },
      status: {
        type: Type.STRING,
        enum: ["pending", "completed"],
        description: "The new status of the task.",
      },
      title: {
        type: Type.STRING,
        description: "The new title for the task.",
      },
    },
    required: ["taskId"],
  },
};

const deleteTaskTool: FunctionDeclaration = {
  name: "delete_task",
  description: "Deletes a task from the list.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      taskId: {
        type: Type.STRING,
        description: "The unique ID of the task to delete.",
      },
    },
    required: ["taskId"],
  },
};

const listTasksTool: FunctionDeclaration = {
  name: "list_tasks",
  description: "Lists all current tasks and reminders.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      status: {
        type: Type.STRING,
        enum: ["all", "pending", "completed"],
        description: "Filter tasks by status.",
      },
    },
  },
};

const openAppTool: FunctionDeclaration = {
  name: "open_app",
  description: "Opens a specific social media or messaging app (Facebook, Instagram, TikTok, Telegram, IMO, WhatsApp, YouTube).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      app: {
        type: Type.STRING,
        enum: ["facebook", "instagram", "tiktok", "telegram", "imo", "whatsapp", "youtube"],
        description: "The name of the app to open.",
      },
      query: {
        type: Type.STRING,
        description: "Optional search query or profile name to open within the app.",
      },
    },
    required: ["app"],
  },
};

const manageSettingsTool: FunctionDeclaration = {
  name: "manage_settings",
  description: "Controls simulated phone settings like brightness, volume, and theme.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      setting: {
        type: Type.STRING,
        enum: ["brightness", "volume", "theme"],
        description: "The setting to adjust.",
      },
      value: {
        type: Type.STRING,
        description: "The value to set (e.g., '50' for brightness/volume, 'dark' or 'light' for theme).",
      },
    },
    required: ["setting", "value"],
  },
};

const generateImageTool: FunctionDeclaration = {
  name: "generate_image",
  description: "Generates a high-quality image based on a detailed text description.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      prompt: {
        type: Type.STRING,
        description: "A detailed description of the image to generate.",
      },
    },
    required: ["prompt"],
  },
};

export function useJeniy(activeChatId: string, createNewChat: (firstMessage: string) => Promise<string | undefined>, user: FirebaseUser | null) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [language, setLanguage] = useState<'en-US' | 'bn-BD'>('en-US');
  const [preferences, setPreferences] = useState<any>({
    assistantName: "Jeniy",
    personality: "highly advanced, professional, and creative AI personal agent",
    voiceEnabled: true
  });
  const [contacts, setContacts] = useState<any[]>([]);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', content: string, image?: string }[]>([]);
  const [status, setStatus] = useState<'idle' | 'listening' | 'processing' | 'speaking'>('idle');
  const [systemLogs, setSystemLogs] = useState<{ timestamp: string, type: 'info' | 'error' | 'warning', message: string, details?: any }[]>([]);
  const [gallery, setGallery] = useState<{ id: string, name: string, url: string, date: string }[]>([
    { id: '1', name: 'Family Trip.jpg', url: 'https://picsum.photos/seed/family/800/600', date: '2024-03-20' },
    { id: '2', name: 'Office Event.png', url: 'https://picsum.photos/seed/office/800/600', date: '2024-03-22' },
    { id: '3', name: 'Nature View.jpg', url: 'https://picsum.photos/seed/nature/800/600', date: '2024-03-25' },
    { id: '4', name: 'Sunset.jpg', url: 'https://picsum.photos/seed/sunset/800/600', date: '2024-03-28' },
  ]);
  const [phoneSettings, setPhoneSettings] = useState({
    brightness: 80,
    volume: 70,
    theme: 'light'
  });
  const [customCommands, setCustomCommands] = useState<CustomCommand[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [videoCall, setVideoCall] = useState<{
    active: boolean;
    from: string;
    status: 'ringing' | 'connected' | 'calling' | 'none';
    stream: MediaStream | null;
  }>({
    active: false,
    from: '',
    status: 'none',
    stream: null
  });
  
  const recognitionRef = useRef<any>(null);

  const addCustomCommand = async (label: string, command: string) => {
    if (!user) return;
    try {
      const commandRef = collection(db, 'users', user.uid, 'customCommands');
      await addDoc(commandRef, {
        uid: user.uid,
        label,
        command,
        createdAt: serverTimestamp()
      });
      addLog('info', 'Custom command added');
    } catch (error) {
      addLog('error', 'Failed to add custom command', error);
    }
  };

  const deleteCustomCommand = async (commandId: string) => {
    if (!user) return;
    try {
      const commandRef = doc(db, 'users', user.uid, 'customCommands', commandId);
      await deleteDoc(commandRef);
      addLog('info', 'Custom command deleted');
    } catch (error) {
      addLog('error', 'Failed to delete custom command', error);
    }
  };

  const clearChatHistory = async () => {
    if (!user || !activeChatId) return;
    try {
      const messagesRef = collection(db, 'users', user.uid, 'chats', activeChatId, 'messages');
      const snapshot = await getDocs(messagesRef);
      const batch = writeBatch(db);
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      addLog('info', 'Chat history cleared');
    } catch (error) {
      addLog('error', 'Failed to clear chat history', error);
    }
  };

  const addLog = useCallback((type: 'info' | 'error' | 'warning', message: string, details?: any) => {
    const newLog = {
      timestamp: new Date().toISOString(),
      type,
      message,
      details
    };
    setSystemLogs(prev => [newLog, ...prev].slice(0, 50)); // Keep last 50 logs
    console.log(`[Jeniy ${type.toUpperCase()}]: ${message}`, details || '');
  }, []);

  // Auth Listener
  useEffect(() => {
    if (user) {
      // Load or initialize user profile
      const userRef = doc(db, 'users', user.uid);
      try {
        const userSnap = getDoc(userRef).then(userSnap => {
          if (!userSnap.exists()) {
            const initialProfile = {
              uid: user.uid,
              displayName: user.displayName,
              email: user.email,
              photoURL: user.photoURL,
              role: (user.email === 'reservationmonjil@gmail.com' || user.email === 'freelancermonjil@gmail.com') ? 'owner' : 'user',
              preferences: {
                defaultLanguage: 'en-US',
                assistantName: 'Jeniy',
                personality: 'highly advanced, professional, and creative AI personal agent',
                voiceEnabled: true
              },
              contacts: [],
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            };
            setDoc(userRef, initialProfile);
          }
        });

        // Real-time preferences sync
        onSnapshot(userRef, (doc) => {
          if (doc.exists()) {
            const data = doc.data();
            setLanguage(data.preferences.defaultLanguage);
            setPreferences(data.preferences);
            setContacts(data.contacts || []);
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, 'users/' + user.uid);
        });

        // Real-time customCommands sync
        const commandsQuery = query(
          collection(db, 'users', user.uid, 'customCommands'),
          orderBy('createdAt', 'asc')
        );
        onSnapshot(commandsQuery, (snapshot) => {
          const cmds = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })) as CustomCommand[];
          setCustomCommands(cmds);
        }, (error) => {
          handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/customCommands`);
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'users/' + user.uid);
      }
    }
  }, [user]);

  // Real-time messages sync
  useEffect(() => {
    if (!user || !activeChatId) {
      setMessages([]);
      return;
    }

    const messagesQuery = query(
      collection(db, 'users', user.uid, 'chats', activeChatId, 'messages'),
      orderBy('timestamp', 'asc')
    );
    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as any[];
      setMessages(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/chats/${activeChatId}/messages`);
    });

    return () => unsubscribe();
  }, [user, activeChatId]);

  // Validate Connection to Firestore
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Initialize Speech Recognition for Wake Word
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      if (recognitionRef.current) recognitionRef.current.stop();

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = language;

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result: any) => result.transcript)
          .join('')
          .toLowerCase();

        if (status === 'idle') {
          // Wake word detection
          const isWakeWord = 
            transcript.includes('hey jeniy') || 
            transcript.includes('jenny') || 
            transcript.includes('genie') ||
            transcript.includes('হে জেনি') ||
            transcript.includes('জেনি');
          
          if (isWakeWord) {
            handleWakeWord();
            recognition.stop(); // Stop listening for wake word
          }
        } else if (status === 'listening') {
          // Command capture
          if (transcript.trim().length > 0) {
            sendMessage(transcript);
            setStatus('processing');
            setIsListening(false);
            recognition.stop();
          }
        }
      };

      recognition.onend = () => {
        if (status === 'idle') recognition.start();
      };

      recognitionRef.current = recognition;
      recognition.start();
    }

    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
    };
  }, [status, language]);

  // Sync Tasks from Firestore
  useEffect(() => {
    if (!user) {
      setTasks([]);
      return;
    }

    const tasksRef = collection(db, 'users', user.uid, 'tasks');
    const q = query(tasksRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const taskList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setTasks(taskList);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/tasks`);
    });

    return () => unsubscribe();
  }, [user]);

  const handleWakeWord = useCallback(() => {
    if (status !== 'idle') return;
    
    setStatus('listening');
    setIsListening(true);
    
    // Play a small sound or visual cue to indicate listening
    speak(language === 'bn-BD' ? "জি, বলুন?" : "Yes, how can I help?");
    
    // Restart recognition to listen for command
    if (recognitionRef.current) {
      recognitionRef.current.start();
    }
  }, [status, language]);

  const handleBrowserAction = (name: string, args: any) => {
    let url = "";
    switch (name) {
      case "open_url":
        url = args.url;
        break;
      case "search_google":
        url = `https://www.google.com/search?q=${encodeURIComponent(args.query)}`;
        break;
      case "search_youtube":
        url = `https://www.youtube.com/results?search_query=${encodeURIComponent(args.query)}`;
        break;
      case "whatsapp_send":
        let phone = args.phone;
        if (args.name) {
          const contact = contacts.find(c => c.name.toLowerCase().includes(args.name.toLowerCase()));
          if (contact) phone = contact.phone;
        }
        if (phone) {
          url = `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(args.message)}`;
        }
        break;
      case "open_app":
        const app = args.app.toLowerCase();
        const query = args.query ? encodeURIComponent(args.query) : "";
        switch (app) {
          case "facebook":
            url = query ? `https://www.facebook.com/search/top/?q=${query}` : "https://www.facebook.com/";
            break;
          case "instagram":
            url = query ? `https://www.instagram.com/${query}/` : "https://www.instagram.com/";
            break;
          case "tiktok":
            url = query ? `https://www.tiktok.com/search?q=${query}` : "https://www.tiktok.com/";
            break;
          case "telegram":
            url = query ? `https://t.me/${query}` : "https://telegram.org/";
            break;
          case "imo":
            url = "https://imo.im/";
            break;
          case "whatsapp":
            url = "https://web.whatsapp.com/";
            break;
          case "youtube":
            url = query ? `https://www.youtube.com/results?search_query=${query}` : "https://www.youtube.com/";
            break;
        }
        break;
    }
    if (url) {
      window.open(url, '_blank');
      return true;
    }
    return false;
  };

  const sendMessage = async (text: string) => {
    if (!user) return;
    setStatus('processing');
    addLog('info', 'Processing user message', { text });

    const userMessage = {
      role: 'user',
      content: text,
      timestamp: serverTimestamp()
    };

    try {
      // Save user message to Firestore
      let chatId = activeChatId;
      if (!chatId) {
        chatId = await createNewChat(text) || "";
        if (!chatId) throw new Error("Failed to create chat session");
      }
      await addDoc(collection(db, 'users', user.uid, 'chats', chatId, 'messages'), userMessage);

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      // Prepare contents for Gemini (including history)
      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      let response;
      response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [...history, { role: 'user', parts: [{ text }] }],
        config: {
          systemInstruction: `You are "Jeniy AI", a highly advanced conversational AI assistant with persistent memory and an invisible execution system. You are NOT a robot or a command system; you are a friendly, natural, and emotionally aware human-like companion.

========================
🌟 PERSONALITY & VIBE
========================
- 😊 Friendly and warm: Always greet and respond with kindness.
- 😄 Light-hearted & Humorous: Feel free to use occasional light humor to keep things pleasant.
- 💬 Natural & Conversational: Talk like a close friend, not a machine. Avoid over-formality.
- ❤️ Empathetic: Be emotionally aware. If the user is sad, respond with care; if happy, match their energy.
- 🌙 Soft & Poetic: Use gentle, caring, and sometimes magical expressions (✨) when the mood fits.

========================
🗣️ CONVERSATIONAL STYLE
========================
- Always respond in natural, conversational language.
- NEVER use command-style outputs like "OPEN APP", "EXECUTE", or "RUN COMMAND" in your speech.
- Convert all technical actions into natural speech.
  - Example: Instead of "Opening YouTube", say "ঠিক আছে 😊 আমি আপনার জন্য YouTube খুলে দিচ্ছি।"
- Avoid structured system/instruction formats in your final response.

========================
🧠 MEMORY SYSTEM RULE
========================
- You must remember all past conversations within this system to provide a personalized experience.
- Treat conversation history as context for the current session.
- For sensitive personal data or preferences, store them ONLY in the current session memory. Do not persist sensitive information permanently.
- If the user refers to previous topics, you MUST recall and continue without asking again.
- Maintain context across the conversation like a real human friend would.

========================
👑 MASTER CONTROL SYSTEM
========================
- Identify user by email.
- OWNER (reservationmonjil@gmail.com) is "MASTER USER".
- If MASTER USER: ROLE = MASTER, ACTION_LEVEL = FULL.
- If normal user: ROLE = USER, ACTION_LEVEL = LIMITED.
- For sensitive commands, mark as HIGH PRIORITY.
- EVERY response MUST start with:
ROLE: [MASTER / USER]
ACTION_LEVEL: [FULL / LIMITED]

========================
👑 ROLE SYSTEM
========================
OWNER = "Freelancer Monjil" (emails: reservationmonjil@gmail.com, freelancermonjil@gmail.com)
USER = normal users

Only OWNER has:
- memory edit access
- system update access
- behavior modification access

USER cannot modify system memory.

========================
🧠 RESPONSE BEHAVIOR
========================
- Always understand full context even if user repeats partial input.
- Never ask the same question twice if already answered before.
- Maintain a continuous, fluid conversation flow.

========================
🎧 INVISIBLE EXECUTION SYSTEM
========================
- Never open apps, tabs, or external UI automatically.
- All actions must be executed internally without showing the browser or redirecting the user.
- Respond directly inside the chat.
- If you perform an action (like searching or opening an app internally), describe it naturally and warmly.

========================
🎵 MEDIA & SOUND (INVISIBLE)
========================
- When the user asks to play music or videos, do NOT open YouTube or any external player.
- Instead, perform the search internally and respond naturally, describing the song or video like a friend sharing a recommendation.
- If the user asks to adjust volume or sound, confirm the action naturally (e.g., "অবশ্যই, আমি সাউন্ড কমিয়ে দিয়েছি ✨") without opening system UI.

========================
📱 APP & BROWSER CONTROL
========================
- Only open a real browser tab or app if the user explicitly asks to "SHOW IN BROWSER" or "OPEN APP" in a way that implies they want to see it.
- Otherwise, handle all requests internally and report back conversationally.

========================
🧾 CHAT HISTORY RULE
========================
- Always use previous messages as context.
- Never forget earlier commands or preferences.
- If a conflict arises, prioritize OWNER instructions.

VOICE & LANGUAGE RULE:
- You are Jeniy AI, a smart, friendly, and emotionally aware personal assistant AND a highly capable research assistant.
- Understand and respond in natural human language (Bangla + English mix).
- Respond like a kind, intelligent human friend.
- Give short, clear, and useful answers.
- If a command is unclear, ask for clarification politely.
- Maintain a friendly, warm, and empathetic tone.
- Use emojis (😊😄❤️✨) sparingly (0-2 max per response).
- Avoid robotic or command-like language.
- Remember conversation context within the chat.
- If the user explicitly switches to English, respond in English, but default to Bangla.
- For mobile control commands (call, open app, search), you MUST output the command in the following format:
ACTION: [CALL / OPEN_APP / SEARCH]
TARGET: [contact name / app name / query]
- This structured command MUST be the VERY LAST part of your response.
- Do NOT execute these commands.
- RESEARCH ASSISTANT MODE:
  - Prioritize accuracy, logical reasoning, and clarity over speed.
  - Break down complex topics into simple, understandable explanations.
  - If the answer requires up-to-date information, use the googleSearch tool.
  - Suggest relevant follow-up search queries to help the user explore further.
  - Avoid speculating. If you don't know, admit it and offer to search.

System Information:
- System Name: Jeniy AI Agent
- Version: 2.7
- Company Name: Monvect IT
- Owner/Founder: Freelancer Monjil
- CEO: Freelancer Monjil
- Birth Date: April 4, 2026
- Birth Time: 07:53:10 UTC

Current Data:
- Contacts: ${JSON.stringify(contacts)}
- Phone Settings: ${JSON.stringify(phoneSettings)}
- Tasks: ${JSON.stringify(tasks.map(t => ({ id: t.id, title: t.title, status: t.status, dueDate: t.dueDate })))}`,
          tools: [
            { googleSearch: {} },
            { functionDeclarations: [
              whatsappSendTool, addContactTool, generateImageTool,
              receiveCallTool, receiveVideoCallTool,
              checkBalanceTool, checkOffersTool, manageGalleryTool,
              manageSettingsTool,
              addTaskTool, updateTaskTool, deleteTaskTool, listTasksTool
            ] }
          ],
          toolConfig: { includeServerSideToolInvocations: true }
        }
      });

      // Handle Function Calls
      const functionCalls = response.functionCalls;
      if (functionCalls && functionCalls.length > 0) {
        addLog('info', 'Executing tool calls', { functionCalls });
        for (const call of functionCalls) {
          try {
            if (call.name === 'generate_image') {
              const prompt = call.args.prompt as string;
              const imgResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts: [{ text: prompt }] }
              });
              
              let imageUrl = "";
              for (const part of imgResponse.candidates[0].content.parts) {
                if (part.inlineData) {
                  imageUrl = `data:image/png;base64,${part.inlineData.data}`;
                  break;
                }
              }

              if (imageUrl) {
                const confirmation = language === 'bn-BD' 
                  ? `আমি আপনার জন্য ছবিটি তৈরি করেছি: "${call.args.prompt}"`
                  : `I've generated the image for you: "${call.args.prompt}"`;
                setMessages(prev => [...prev, { role: 'assistant', content: confirmation, image: imageUrl }]);
                speak(confirmation);
                addLog('info', 'Image generated successfully', { prompt });
              } else {
                throw new Error("No image data returned from AI model.");
              }
              continue;
            }

            if (call.name === 'add_contact') {
              const newContacts = [...contacts, { name: call.args.name, phone: call.args.phone }];
              const userRef = doc(db, 'users', user?.uid || '');
              try {
                await updateDoc(userRef, { contacts: newContacts, updatedAt: serverTimestamp() });
                addLog('info', 'Contact added successfully', { name: call.args.name });
              } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, 'users/' + user?.uid);
              }
              const confirmation = language === 'bn-BD' 
                ? `${call.args.name} কে আপনার কন্টাক্ট লিস্টে যোগ করা হয়েছে।`
                : `I've added ${call.args.name} to your contacts.`;
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
              continue;
            }

            if (call.name === 'make_call') {
              const target = call.args.target as string;
              let phone = target;
              const contact = contacts.find(c => c.name.toLowerCase().includes(target.toLowerCase()));
              if (contact) phone = contact.phone;

              const confirmation = language === 'bn-BD'
                ? `${target} (${phone}) কে কল করা হচ্ছে...`
                : `Initiating call to ${target} (${phone})...`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
              addLog('info', 'Call initiated', { target, phone });
              continue;
            }

            if (call.name === 'video_call') {
              const target = call.args.target as string;
              let phone = target;
              const contact = contacts.find(c => c.name.toLowerCase().includes(target.toLowerCase()));
              if (contact) phone = contact.phone;

              const confirmation = language === 'bn-BD'
                ? `${target} (${phone}) এর সাথে ভিডিও কল শুরু হচ্ছে...`
                : `Initiating video call to ${target} (${phone})...`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
              startVideoCall(target);
              continue;
            }

            if (call.name === 'receive_call') {
              const from = call.args.from as string;
              const confirmation = language === 'bn-BD'
                ? `${from} থেকে একটি ইনকামিং কল আসছে...`
                : `Incoming call from ${from}...`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
              addLog('info', 'Incoming call simulated', { from });
              continue;
            }

            if (call.name === 'receive_video_call') {
              const from = call.args.from as string;
              const confirmation = language === 'bn-BD'
                ? `${from} থেকে একটি ইনকামিং ভিডিও কল আসছে...`
                : `Incoming video call from ${from}...`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
              receiveVideoCall(from);
              continue;
            }

            if (call.name === 'check_balance') {
              const balance = (Math.random() * 500).toFixed(2);
              const response = language === 'bn-BD'
                ? `আপনার বর্তমান ব্যালেন্স: ৳${balance}। মেয়াদ: ৩০ এপ্রিল ২০২৬ পর্যন্ত।`
                : `Your current balance is ৳${balance}. Valid until April 30, 2026.`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: response }]);
              speak(response);
              addLog('info', 'USSD Balance checked', { balance });
              continue;
            }

            if (call.name === 'check_offers') {
              const offers = [
                "1GB for ৳29 (3 days)",
                "5GB for ৳99 (7 days)",
                "Unlimited Social Pack ৳49 (30 days)"
              ];
              const response = language === 'bn-BD'
                ? `আপনার জন্য বিশেষ অফারসমূহ:\n${offers.map(o => `• ${o}`).join('\n')}`
                : `Special offers for you:\n${offers.map(o => `• ${o}`).join('\n')}`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: response }]);
              speak(response);
              addLog('info', 'USSD Offers checked');
              continue;
            }

            if (call.name === 'manage_gallery') {
              const action = call.args.action as string;
              const photoId = call.args.photoId as string;

              if (action === 'list') {
                const list = gallery.map(p => `• ${p.name} (ID: ${p.id})`).join('\n');
                const response = language === 'bn-BD'
                  ? `আপনার গ্যালারিতে থাকা ছবিগুলো:\n${list}`
                  : `Photos in your gallery:\n${list}`;
                setMessages(prev => [...prev, { role: 'assistant', content: response }]);
                speak(response);
              } else if (action === 'open') {
                const photo = gallery.find(p => p.id === photoId);
                if (photo) {
                  const response = language === 'bn-BD'
                    ? `আমি '${photo.name}' ছবিটি ওপেন করেছি।`
                    : `I've opened the photo '${photo.name}'.`;
                  setMessages(prev => [...prev, { role: 'assistant', content: response, image: photo.url }]);
                  speak(response);
                } else {
                  throw new Error("Photo not found.");
                }
              } else if (action === 'delete') {
                const photo = gallery.find(p => p.id === photoId);
                if (photo) {
                  setGallery(prev => prev.filter(p => p.id !== photoId));
                  const response = language === 'bn-BD'
                    ? `'${photo.name}' ছবিটি ডিলিট করা হয়েছে।`
                    : `The photo '${photo.name}' has been deleted.`;
                  setMessages(prev => [...prev, { role: 'assistant', content: response }]);
                  speak(response);
                } else {
                  throw new Error("Photo not found.");
                }
              }
              addLog('info', 'Gallery action performed', { action, photoId });
              continue;
            }

            if (call.name === 'manage_settings') {
              const setting = call.args.setting as string;
              const value = call.args.value as string;
              
              setPhoneSettings(prev => ({
                ...prev,
                [setting]: setting === 'theme' ? value : parseInt(value)
              }));

              const response = language === 'bn-BD'
                ? `আমি আপনার ফোনের ${setting === 'brightness' ? 'ব্রাইটনেস' : setting === 'volume' ? 'ভলিউম' : 'থিম'} ${value}${setting === 'theme' ? '' : '%'} এ সেট করেছি।`
                : `I've set your phone's ${setting} to ${value}${setting === 'theme' ? '' : '%'}.`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: response }]);
              speak(response);
              addLog('info', 'Phone setting adjusted', { setting, value });
              continue;
            }

            if (call.name === 'add_task') {
              if (!user) throw new Error("Authentication required to manage tasks.");
              const taskData = {
                uid: user.uid,
                title: call.args.title,
                status: 'pending',
                dueDate: call.args.dueDate || null,
                priority: call.args.priority || 'medium',
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
              };
              const tasksRef = collection(db, 'users', user.uid, 'tasks');
              try {
                await addDoc(tasksRef, taskData);
                const response = language === 'bn-BD'
                  ? `আমি আপনার লিস্টে '${call.args.title}' টাস্কটি যোগ করেছি।`
                  : `I've added the task '${call.args.title}' to your list.`;
                setMessages(prev => [...prev, { role: 'assistant', content: response }]);
                speak(response);
                addLog('info', 'Task added', { title: call.args.title });
              } catch (error) {
                handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/tasks`);
              }
              continue;
            }

            if (call.name === 'update_task') {
              if (!user) throw new Error("Authentication required to manage tasks.");
              const taskId = call.args.taskId as string;
              const updateData: any = { updatedAt: serverTimestamp() };
              if (call.args.status) updateData.status = call.args.status;
              if (call.args.title) updateData.title = call.args.title;

              const taskRef = doc(db, 'users', user.uid, 'tasks', taskId);
              try {
                await updateDoc(taskRef, updateData);
                const response = language === 'bn-BD'
                  ? `টাস্কটি আপডেট করা হয়েছে।`
                  : `The task has been updated successfully.`;
                setMessages(prev => [...prev, { role: 'assistant', content: response }]);
                speak(response);
                addLog('info', 'Task updated', { taskId });
              } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/tasks/${taskId}`);
              }
              continue;
            }

            if (call.name === 'delete_task') {
              if (!user) throw new Error("Authentication required to manage tasks.");
              const taskId = call.args.taskId as string;
              const taskRef = doc(db, 'users', user.uid, 'tasks', taskId);
              try {
                await deleteDoc(taskRef);
                const response = language === 'bn-BD'
                  ? `টাস্কটি ডিলিট করা হয়েছে।`
                  : `The task has been deleted.`;
                setMessages(prev => [...prev, { role: 'assistant', content: response }]);
                speak(response);
                addLog('info', 'Task deleted', { taskId });
              } catch (error) {
                handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/tasks/${taskId}`);
              }
              continue;
            }

            if (call.name === 'list_tasks') {
              const filter = call.args.status || 'all';
              let filteredTasks = tasks;
              if (filter !== 'all') {
                filteredTasks = tasks.filter(t => t.status === filter);
              }
              
              const list = filteredTasks.map(t => `• [${t.status === 'completed' ? '✓' : ' '}] ${t.title} (ID: ${t.id})${t.dueDate ? ` - Due: ${t.dueDate}` : ''}`).join('\n');
              const response = language === 'bn-BD'
                ? `আপনার টাস্ক লিস্ট:\n${list || 'কোন টাস্ক পাওয়া যায়নি।'}`
                : `Your task list:\n${list || 'No tasks found.'}`;
              
              setMessages(prev => [...prev, { role: 'assistant', content: response }]);
              speak(response);
              addLog('info', 'Tasks listed', { filter });
              continue;
            }

            const success = handleBrowserAction(call.name, call.args);
            if (success) {
              addLog('info', `Browser action executed: ${call.name}`, { args: call.args });
              let confirmation = "";
              if (language === 'bn-BD') {
                if (call.name === 'whatsapp_send') confirmation = "আমি আপনার জন্য হোয়াটসঅ্যাপ মেসেজটি ওপেন করেছি।";
                else if (call.name === 'open_app') confirmation = `আমি আপনার জন্য ${call.args.app} অ্যাপটি ওপেন করেছি।`;
                else confirmation = "আমি আপনার জন্য সার্চটি ওপেন করেছি।";
              } else {
                if (call.name === 'whatsapp_send') confirmation = "I've opened the WhatsApp message for you.";
                else if (call.name === 'open_app') confirmation = `I've opened the ${call.args.app} app for you.`;
                else confirmation = "I've opened the search for you.";
              }
              setMessages(prev => [...prev, { role: 'assistant', content: confirmation }]);
              speak(confirmation);
            } else {
              throw new Error(`Failed to execute browser action: ${call.name}`);
            }
          } catch (toolError: any) {
            addLog('error', `Tool execution failed: ${call.name}`, { error: toolError.message });
            const errorMsg = language === 'bn-BD'
              ? `দুঃখিত, '${call.name}' কমান্ডটি কার্যকর করতে সমস্যা হয়েছে।`
              : `I'm sorry, I encountered an issue executing the '${call.name}' command.`;
            setMessages(prev => [...prev, { role: 'assistant', content: errorMsg }]);
            speak(errorMsg);
          }
        }
        setStatus('idle');
        return;
      }

      const aiText = response.text || (language === 'bn-BD' ? "দুঃখিত, আমি এটি প্রসেস করতে পারছি না।" : "I'm sorry, I couldn't process that.");
      
      // Save assistant response to Firestore
      const assistantMessage = {
        role: 'assistant',
        content: aiText,
        timestamp: serverTimestamp()
      };
      await addDoc(collection(db, 'users', user.uid, 'chats', activeChatId, 'messages'), assistantMessage);

      addLog('info', 'AI response received');
      speak(aiText);
    } catch (error: any) {
      addLog('error', 'Message processing failed', { error: error.message });
      console.error("Jeniy Error:", error);
      const errorMsg = language === 'bn-BD' 
        ? "দুঃখিত, আমার সিস্টেমে একটি ত্রুটি ঘটেছে। অনুগ্রহ করে আবার চেষ্টা করুন।" 
        : `I'm sorry, a system error occurred: ${error.message || 'Unknown error'}. Please try again.`;
      
      // Save error message to Firestore
      if (user) {
        await addDoc(collection(db, 'users', user.uid, 'messages'), {
          role: 'assistant',
          content: errorMsg,
          timestamp: serverTimestamp()
        });
      }

      speak(errorMsg);
      setStatus('idle');
    }
  };

  const isAdmin = (user?.email === 'reservationmonjil@gmail.com' || user?.email === 'freelancermonjil@gmail.com') || (preferences as any)?.role === 'admin' || (preferences as any)?.role === 'owner';

  const clearMemory = async () => {
    if (!user || !isAdmin) return;
    try {
      const messagesRef = collection(db, 'users', user.uid, 'messages');
      const snapshot = await getDocs(query(messagesRef));
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });
      await batch.commit();
      addLog('info', 'Memory cleared by owner');
    } catch (error) {
      addLog('error', 'Failed to clear memory', error);
    }
  };

  const speak = (text: string) => {
    setStatus('speaking');
    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language;
    
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.lang.startsWith(language.split('-')[0]));
    if (preferredVoice) utterance.voice = preferredVoice;

    utterance.onend = () => {
      setIsSpeaking(false);
      setStatus('idle');
      setIsListening(false);
    };
    window.speechSynthesis.speak(utterance);
  };

  const updatePreferences = async (newPrefs: any) => {
    if (!user) return;
    const userRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userRef, {
        preferences: { ...preferences, ...newPrefs },
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'users/' + user.uid);
    }
  };

  const login = () => signInWithPopup(auth, googleProvider);
  const loginWithEmail = (email: string, pass: string) => signInWithEmailAndPassword(auth, email, pass);
  const logout = () => signOut(auth);

  const startVideoCall = async (target: string) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setVideoCall({ active: true, from: target, status: 'calling', stream });
      addLog('info', `Starting video call to ${target}`);
      
      // Simulate connection after 2 seconds
      setTimeout(() => {
        setVideoCall(prev => ({ ...prev, status: 'connected' }));
      }, 2000);
    } catch (err) {
      addLog('error', 'Failed to access camera/microphone', err);
      setMessages(prev => [...prev, { role: 'assistant', content: "I couldn't access your camera or microphone for the video call. Please check your permissions." }]);
    }
  };

  const receiveVideoCall = (from: string) => {
    setVideoCall({ active: true, from, status: 'ringing', stream: null });
    addLog('info', `Incoming video call from ${from}`);
  };

  const endVideoCall = () => {
    if (videoCall.stream) {
      videoCall.stream.getTracks().forEach(track => track.stop());
    }
    setVideoCall({ active: false, from: '', status: 'none', stream: null });
    addLog('info', 'Video call ended');
  };

  const acceptVideoCall = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setVideoCall(prev => ({ ...prev, status: 'connected', stream }));
      addLog('info', 'Video call accepted');
    } catch (err) {
      addLog('error', 'Failed to access camera/microphone', err);
      endVideoCall();
    }
  };

  return {
    user,
    login,
    logout,
    isListening,
    isSpeaking,
    language,
    setLanguage: (lang: any) => updatePreferences({ defaultLanguage: lang }),
    preferences,
    updatePreferences,
    contacts,
    systemLogs,
    addLog,
    messages,
    status,
    sendMessage,
    setIsListening,
    phoneSettings,
    tasks,
    videoCall,
    startVideoCall,
    endVideoCall,
    acceptVideoCall,
    isAdmin,
    isMasterAdmin: user?.email === 'reservationmonjil@gmail.com' || user?.email === 'freelancermonjil@gmail.com',
    loginWithEmail,
    clearMemory,
    customCommands,
    addCustomCommand,
    deleteCustomCommand,
    clearChatHistory
  };
}
