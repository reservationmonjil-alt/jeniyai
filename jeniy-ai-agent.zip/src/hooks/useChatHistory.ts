import { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { collection, addDoc, deleteDoc, doc, query, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

export interface Chat {
  id: string;
  title: string;
  createdAt: any;
  updatedAt: any;
}

export const useChatHistory = (user: FirebaseUser | null) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string>('');

  useEffect(() => {
    if (!user) {
      setChats([]);
      setActiveChatId('');
      return;
    }

    const chatsQuery = query(
      collection(db, 'users', user.uid, 'chats'),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(chatsQuery, (snapshot) => {
      const chatList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Chat[];
      setChats(chatList);
      if (chatList.length > 0 && !activeChatId) {
        setActiveChatId(chatList[0].id);
      }
    });

    return () => unsubscribe();
  }, [user]);

  const createNewChat = async (firstMessage: string) => {
    if (!user) {
      console.error("createNewChat: user is null");
      return;
    }
    console.log("createNewChat: creating chat for user", user.uid);
    const title = firstMessage.substring(0, 30) + (firstMessage.length > 30 ? '...' : '');
    const chatRef = await addDoc(collection(db, 'users', user.uid, 'chats'), {
      title,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    console.log("createNewChat: chat created", chatRef.id);
    setActiveChatId(chatRef.id);
    return chatRef.id;
  };

  const deleteChat = async (chatId: string) => {
    if (!user) return;
    await deleteDoc(doc(db, 'users', user.uid, 'chats', chatId));
    if (activeChatId === chatId) {
      setActiveChatId(chats.length > 1 ? chats.find(c => c.id !== chatId)?.id || '' : '');
    }
  };

  const setActiveChat = (chatId: string) => {
    setActiveChatId(chatId);
  };

  return { chats, activeChatId, createNewChat, deleteChat, setActiveChat };
};
