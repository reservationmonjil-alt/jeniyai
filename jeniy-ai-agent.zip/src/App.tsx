import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from "motion/react";
import { 
  Mic, Send, Youtube, Globe, Settings, Terminal, MessageSquare, 
  Volume2, VolumeX, User, LogOut, X, Save, ShieldCheck, Phone, 
  Plus, Trash2, Sun, Volume1, Moon, CheckCircle2, Circle, Clock, ListTodo,
  Facebook, Info, ExternalLink, Video, VideoOff, MicOff, PhoneOff, PhoneCall,
  Crown, Activity, Database, Server, FileText, Calendar as CalendarIcon, Merge
} from "lucide-react";
import Visualizer from "./components/Visualizer";
import SplashScreen from "./components/SplashScreen";
import { Sidebar } from "./components/Sidebar";
import { ChatArea } from "./components/ChatArea";
import { ChatLayout } from "./components/ChatLayout";
import { JpgToPdfConverter } from "./components/JpgToPdfConverter";
import { PdfToJpgConverter } from "./components/PdfToJpgConverter";
import { PdfMerger } from "./components/PdfMerger";
import { VoiceChat } from "./components/VoiceChat";
import { useJeniy } from "./hooks/useJeniy";
import { useChatHistory } from "./hooks/useChatHistory";
import ReactMarkdown from "react-markdown";
import { cn } from "./lib/utils";
import ReactCalendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from './firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });
    return () => unsubscribe();
  }, []);

  const { chats, activeChatId, createNewChat, deleteChat, setActiveChat } = useChatHistory(user);
  const { 
    login, logout, 
    isListening, isSpeaking, language, setLanguage, 
    preferences, updatePreferences, contacts,
    systemLogs, addLog,
    messages, status, sendMessage, setIsListening,
    phoneSettings, tasks,
    videoCall, startVideoCall, endVideoCall, acceptVideoCall,
    isAdmin, isMasterAdmin, loginWithEmail, clearMemory,
    customCommands, addCustomCommand, deleteCustomCommand, clearChatHistory
  } = useJeniy(activeChatId, createNewChat, user);
  
  const [inputText, setInputText] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const [isAppLoading, setIsAppLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showVoiceChat, setShowVoiceChat] = useState(false);
  const [activeTab, setActiveTab] = useState<'settings' | 'contacts' | 'tasks' | 'logs' | 'about' | 'admin' | 'commands' | 'converter' | 'merger' | 'pdfToJpg'>('settings');
  const [editPrefs, setEditPrefs] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '' });
  const [newCommand, setNewCommand] = useState({ label: '', command: '' });
  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && videoCall.stream) {
      videoRef.current.srcObject = videoCall.stream;
    }
  }, [videoCall.stream]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAppLoading(false);
    }, 4500); // 4.5 seconds to allow animations to play
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (preferences) setEditPrefs(preferences);
  }, [preferences]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    sendMessage(inputText);
    setInputText("");
  };

  const handleSavePrefs = async () => {
    await updatePreferences(editPrefs);
    setShowProfile(false);
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);
    try {
      await loginWithEmail(email, password);
      setEmail('');
      setPassword('');
    } catch (err: any) {
      setLoginError(err.message || 'Failed to login');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAddContact = async () => {
    if (!newContact.name || !newContact.phone || !user) return;
    const userRef = doc(db, 'users', user.uid);
    await updateDoc(userRef, {
      contacts: [...contacts, newContact],
      updatedAt: serverTimestamp()
    });
    setNewContact({ name: '', phone: '' });
  };

  const handleDeleteContact = async (index: number) => {
    if (!user) return;
    const updatedContacts = contacts.filter((_, i) => i !== index);
    const userRef = doc(db, 'users', user.uid);
    await updateDoc(userRef, {
      contacts: updatedContacts,
      updatedAt: serverTimestamp()
    });
  };

  return (
    <div className="min-h-screen bg-[#050505] text-slate-200 font-sans selection:bg-cyan-500/30 overflow-hidden flex flex-col">
      <AnimatePresence mode="wait">
        {isAppLoading && (
          <SplashScreen key="splash" onComplete={() => setIsAppLoading(false)} />
        )}
      </AnimatePresence>

      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex items-center justify-between border-b border-white/5 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
            <Terminal className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-white">{preferences?.assistantName?.toUpperCase() || 'JENIY'} <span className="text-cyan-500 text-xs font-mono ml-1">v2.5</span></h1>
            <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">System Active // Secure Link</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Language Toggle */}
          <div className="flex bg-white/5 rounded-lg p-1 border border-white/10">
            <button 
              onClick={() => setLanguage('en-US')}
              className={cn(
                "px-3 py-1 rounded-md text-[10px] font-mono transition-all",
                language === 'en-US' ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" : "text-slate-500 hover:text-slate-300"
              )}
            >
              ENG
            </button>
            <button 
              onClick={() => setLanguage('bn-BD')}
              className={cn(
                "px-3 py-1 rounded-md text-[10px] font-mono transition-all",
                language === 'bn-BD' ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" : "text-slate-500 hover:text-slate-300"
              )}
            >
              BNG
            </button>
          </div>

          <div className="hidden md:flex items-center gap-6 text-xs font-mono text-slate-400 mr-4">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span>CORE_STABLE</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3 h-3 text-cyan-500" />
              <span>AUTH_{user ? 'VERIFIED' : 'GUEST'}</span>
            </div>
          </div>
          
          <button 
            onClick={() => setShowProfile(true)}
            className="p-2 rounded-full hover:bg-white/5 transition-colors relative"
          >
            {user?.photoURL ? (
              <img src={user.photoURL} alt="Profile" className="w-6 h-6 rounded-full border border-white/20" />
            ) : (
              <User className="w-5 h-5 text-slate-400" />
            )}
            {user && <div className="absolute top-0 right-0 w-2 h-2 bg-cyan-500 rounded-full border border-black" />}
          </button>
        </div>
      </header>

      <main className="relative z-10 flex-1 overflow-hidden">
        <ChatLayout 
          messages={messages} 
          onSendMessage={sendMessage} 
          isDarkMode={isDarkMode} 
          toggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          chats={chats}
          activeChatId={activeChatId}
          onNewChat={() => createNewChat("New Chat")}
          onSelectChat={setActiveChat}
          onDeleteChat={deleteChat}
          onClearHistory={clearChatHistory}
        />
      </main>


      {/* Profile/Settings Modal */}
      <AnimatePresence>
        {showProfile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowProfile(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setActiveTab('settings')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'settings' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Settings className="w-4 h-4" />
                    Settings
                  </button>
                  <button 
                    onClick={() => setActiveTab('converter')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'converter' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <FileText className="w-4 h-4" />
                    Converter
                  </button>
                  <button 
                    onClick={() => setActiveTab('pdfToJpg')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'pdfToJpg' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <FileText className="w-4 h-4" />
                    PDF to JPG
                  </button>
                  <button 
                    onClick={() => setActiveTab('merger')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'merger' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Merge className="w-4 h-4" />
                    Merger
                  </button>
                  <button 
                    onClick={() => setActiveTab('contacts')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'contacts' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Phone className="w-4 h-4" />
                    Contacts
                  </button>
                  <button 
                    onClick={() => setActiveTab('tasks')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'tasks' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <ListTodo className="w-4 h-4" />
                    Tasks
                  </button>
                  <button 
                    onClick={() => setActiveTab('commands')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'commands' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Terminal className="w-4 h-4" />
                    Commands
                  </button>
                  <button 
                    onClick={() => setActiveTab('logs')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'logs' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Activity className="w-4 h-4" />
                    Logs
                  </button>
                  <button 
                    onClick={() => setActiveTab('about')}
                    className={cn(
                      "text-sm font-semibold transition-colors flex items-center gap-2",
                      activeTab === 'about' ? "text-cyan-400" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <Info className="w-4 h-4" />
                    About
                  </button>
                  {isAdmin && (
                    <button 
                      onClick={() => setActiveTab('admin')}
                      className={cn(
                        "text-sm font-semibold transition-colors flex items-center gap-2",
                        activeTab === 'admin' ? (isMasterAdmin ? "text-cyan-400" : "text-amber-400") : "text-slate-500 hover:text-slate-300"
                      )}
                    >
                      {isMasterAdmin ? <ShieldCheck className="w-4 h-4" /> : <Crown className="w-4 h-4" />}
                      {isMasterAdmin ? 'Master' : 'Admin'}
                    </button>
                  )}
                </div>
                <button onClick={() => setShowProfile(false)} className="p-1 hover:bg-white/5 rounded-full">
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                {user ? (
                  <>
                    {activeTab === 'settings' ? (
                      <>
                        <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                          <img src={user.photoURL || ''} alt="" className="w-12 h-12 rounded-full border border-cyan-500/30" />
                          <div>
                            <p className="text-sm font-medium text-white">{user.displayName}</p>
                            <p className="text-xs text-slate-500">{user.email}</p>
                          </div>
                          <button onClick={logout} className="ml-auto p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                            <LogOut className="w-5 h-5" />
                          </button>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <label className="text-[10px] font-mono text-slate-500 uppercase mb-1 block">Assistant Name</label>
                            <input 
                              type="text" 
                              value={editPrefs?.assistantName || ''}
                              onChange={(e) => setEditPrefs({ ...editPrefs, assistantName: e.target.value })}
                              className="w-full bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-mono text-slate-500 uppercase mb-1 block">Personality Matrix</label>
                            <textarea 
                              rows={3}
                              value={editPrefs?.personality || ''}
                              onChange={(e) => setEditPrefs({ ...editPrefs, personality: e.target.value })}
                              className="w-full bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50 resize-none"
                            />
                          </div>
                        </div>

                        <button 
                          onClick={handleSavePrefs}
                          className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
                        >
                          <Save className="w-4 h-4" />
                          Save Preferences
                        </button>

                        <div className="pt-6 border-t border-white/10">
                          <label className="text-[10px] font-mono text-slate-500 uppercase mb-4 block">Simulated Phone Settings</label>
                          <div className="grid grid-cols-3 gap-3">
                            <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex flex-col items-center gap-2">
                              <Sun className="w-4 h-4 text-yellow-400" />
                              <span className="text-[10px] font-mono text-slate-400">Brightness</span>
                              <span className="text-sm font-bold text-white">{phoneSettings.brightness}%</span>
                            </div>
                            <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex flex-col items-center gap-2">
                              <Volume1 className="w-4 h-4 text-blue-400" />
                              <span className="text-[10px] font-mono text-slate-400">Volume</span>
                              <span className="text-sm font-bold text-white">{phoneSettings.volume}%</span>
                            </div>
                            <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex flex-col items-center gap-2">
                              {phoneSettings.theme === 'dark' ? <Moon className="w-4 h-4 text-purple-400" /> : <Sun className="w-4 h-4 text-orange-400" />}
                              <span className="text-[10px] font-mono text-slate-400">Theme</span>
                              <span className="text-sm font-bold text-white capitalize">{phoneSettings.theme}</span>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : activeTab === 'converter' ? (
                      <JpgToPdfConverter isDarkMode={isDarkMode} />
                    ) : activeTab === 'pdfToJpg' ? (
                      <PdfToJpgConverter isDarkMode={isDarkMode} />
                    ) : activeTab === 'merger' ? (
                      <PdfMerger isDarkMode={isDarkMode} />
                    ) : activeTab === 'contacts' ? (
                      <div className="space-y-6">
                        <div className="space-y-3">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">Add New Contact</label>
                          <div className="flex gap-2">
                            <input 
                              type="text" 
                              placeholder="Name"
                              value={newContact.name}
                              onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                              className="flex-1 bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                            />
                            <input 
                              type="text" 
                              placeholder="+880..."
                              value={newContact.phone}
                              onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                              className="flex-1 bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                            />
                            <button 
                              onClick={handleAddContact}
                              className="p-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg transition-all"
                            >
                              <Plus className="w-5 h-5" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">Saved Contacts ({contacts.length})</label>
                          {contacts.length === 0 ? (
                            <p className="text-xs text-slate-600 italic py-4 text-center">No contacts saved yet.</p>
                          ) : (
                            <div className="space-y-2">
                              {contacts.map((contact, i) => (
                                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 group">
                                  <div>
                                    <p className="text-sm font-medium text-white">{contact.name}</p>
                                    <p className="text-xs text-slate-500 font-mono">{contact.phone}</p>
                                  </div>
                                  <button 
                                    onClick={() => handleDeleteContact(i)}
                                    className="p-2 text-slate-600 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ) : activeTab === 'tasks' ? (
                      <div className="space-y-6">
                        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                          <ReactCalendar 
                            className="!bg-transparent !border-none !text-white w-full"
                            tileClassName={({ date, view }) => view === 'month' && tasks.some(t => t.dueDate === date.toISOString().split('T')[0]) ? 'bg-cyan-500/20 text-cyan-400' : ''}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">My Tasks ({tasks.length})</label>
                          <div className="flex gap-2">
                            <span className="text-[10px] font-mono text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded">
                              {tasks.filter(t => t.status === 'pending').length} Pending
                            </span>
                            <span className="text-[10px] font-mono text-green-500 bg-green-500/10 px-2 py-0.5 rounded">
                              {tasks.filter(t => t.status === 'completed').length} Done
                            </span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {tasks.length === 0 ? (
                            <div className="text-center py-8 bg-white/5 rounded-xl border border-dashed border-white/10">
                              <ListTodo className="w-8 h-8 text-slate-600 mx-auto mb-2 opacity-20" />
                              <p className="text-xs text-slate-500 italic">No tasks yet. Ask Jeniy to add one!</p>
                            </div>
                          ) : (
                            tasks.map((task) => (
                              <div key={task.id} className={cn(
                                "p-3 rounded-xl border transition-all group",
                                task.status === 'completed' ? "bg-black/20 border-white/5 opacity-60" : "bg-white/5 border-white/10"
                              )}>
                                <div className="flex items-start gap-3">
                                  <button 
                                    onClick={() => sendMessage(`Update task ${task.id} status to ${task.status === 'completed' ? 'pending' : 'completed'}`)}
                                    className={cn(
                                      "mt-0.5 transition-colors",
                                      task.status === 'completed' ? "text-green-500" : "text-slate-500 hover:text-cyan-400"
                                    )}
                                  >
                                    {task.status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                                  </button>
                                  <div className="flex-1 min-w-0">
                                    <p className={cn(
                                      "text-sm font-medium text-white break-words",
                                      task.status === 'completed' && "line-through text-slate-500"
                                    )}>
                                      {task.title}
                                    </p>
                                    <div className="flex flex-wrap gap-3 mt-1.5">
                                      {task.dueDate && (
                                        <div className="flex items-center gap-1 text-[10px] text-slate-500 font-mono">
                                          <CalendarIcon className="w-3 h-3" />
                                          {task.dueDate}
                                        </div>
                                      )}
                                      <div className={cn(
                                        "text-[9px] font-mono px-1.5 py-0.5 rounded uppercase flex items-center gap-1",
                                        task.priority === 'high' ? "bg-red-500/10 text-red-400" :
                                        task.priority === 'medium' ? "bg-yellow-500/10 text-yellow-400" : "bg-blue-500/10 text-blue-400"
                                      )}>
                                        <div className={cn("w-1.5 h-1.5 rounded-full", task.priority === 'high' ? "bg-red-500" : task.priority === 'medium' ? "bg-yellow-500" : "bg-blue-500")} />
                                        {task.priority}
                                      </div>
                                    </div>
                                  </div>
                                  <button 
                                    onClick={() => sendMessage(`Delete task ${task.id}`)}
                                    className="p-1.5 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    ) : activeTab === 'commands' ? (
                      <div className="space-y-6">
                        <div className="space-y-3">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">Add New Custom Command</label>
                          <div className="flex gap-2">
                            <input 
                              type="text" 
                              placeholder="Button Label"
                              value={newCommand.label}
                              onChange={(e) => setNewCommand({ ...newCommand, label: e.target.value })}
                              className="flex-1 bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                            />
                            <input 
                              type="text" 
                              placeholder="Command text..."
                              value={newCommand.command}
                              onChange={(e) => setNewCommand({ ...newCommand, command: e.target.value })}
                              className="flex-1 bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                            />
                            <button 
                              onClick={() => {
                                if (!newCommand.label || !newCommand.command) return;
                                addCustomCommand(newCommand.label, newCommand.command);
                                setNewCommand({ label: '', command: '' });
                              }}
                              className="p-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg transition-all"
                            >
                              <Plus className="w-5 h-5" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">My Commands ({customCommands.length})</label>
                          {customCommands.length === 0 ? (
                            <p className="text-xs text-slate-600 italic py-4 text-center">No custom commands defined yet.</p>
                          ) : (
                            <div className="space-y-2">
                              {customCommands.map((cmd) => (
                                <div key={cmd.id} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 group">
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-white truncate">{cmd.label}</p>
                                    <p className="text-xs text-slate-500 font-mono truncate">{cmd.command}</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <button 
                                      onClick={() => sendMessage(cmd.command)}
                                      className="p-2 text-cyan-500 hover:bg-cyan-500/10 rounded-lg transition-all"
                                    >
                                      <Send className="w-4 h-4" />
                                    </button>
                                    <button 
                                      onClick={() => deleteCustomCommand(cmd.id)}
                                      className="p-2 text-slate-600 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ) : activeTab === 'about' ? (
                      <div className="space-y-6">
                        <div className="text-center py-6">
                          <div className="w-20 h-20 bg-cyan-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-cyan-500/20 shadow-[0_0_30px_-10px_rgba(6,182,212,0.5)]">
                            <ShieldCheck className="w-10 h-10 text-cyan-400" />
                          </div>
                          <h3 className="text-2xl font-bold text-white tracking-tight">Monvect IT</h3>
                          <p className="text-slate-500 text-sm mt-1 font-mono">Advanced AI Solutions & IT Services</p>
                        </div>

                        <div className="space-y-4">
                          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                            <label className="text-[10px] font-mono text-slate-500 uppercase mb-2 block">Leadership</label>
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-cyan-400 font-bold border border-white/5">
                                FM
                              </div>
                              <div>
                                <p className="text-sm font-semibold text-white">Freelancer Monjil</p>
                                <p className="text-xs text-slate-500">CEO & Founder</p>
                              </div>
                            </div>
                          </div>

                          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                            <label className="text-[10px] font-mono text-slate-500 uppercase mb-2 block">Connect With Us</label>
                            <a 
                              href="https://www.facebook.com/freelancermonjill" 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center justify-between p-3 rounded-lg bg-[#1877F2]/10 border border-[#1877F2]/20 hover:bg-[#1877F2]/20 transition-all group"
                            >
                              <div className="flex items-center gap-3">
                                <Facebook className="w-5 h-5 text-[#1877F2]" />
                                <span className="text-sm font-medium text-white">Facebook Page</span>
                              </div>
                              <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                            </a>
                          </div>

                          <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/10">
                            <p className="text-xs text-slate-400 leading-relaxed italic">
                              "Monvect IT is dedicated to pushing the boundaries of artificial intelligence and digital innovation, creating tools that empower users worldwide."
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : activeTab === 'admin' && isAdmin ? (
                      <div className="space-y-6">
                        <div className={cn(
                          "p-4 rounded-2xl flex items-center gap-4",
                          isMasterAdmin ? "bg-cyan-500/10 border border-cyan-500/20" : "bg-amber-500/10 border border-amber-500/20"
                        )}>
                          <div className={cn(
                            "w-12 h-12 rounded-full flex items-center justify-center",
                            isMasterAdmin ? "bg-cyan-500/20" : "bg-amber-500/20"
                          )}>
                            {isMasterAdmin ? <ShieldCheck className="w-6 h-6 text-cyan-400" /> : <Crown className="w-6 h-6 text-amber-400" />}
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-white">{isMasterAdmin ? 'Master Control' : 'Admin Access'}</h3>
                            <p className={cn(
                              "text-xs font-mono uppercase",
                              isMasterAdmin ? "text-cyan-400/70" : "text-amber-400/70"
                            )}>{isMasterAdmin ? 'Absolute Authority Protocol Active' : 'System Management Active'}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                            <Activity className="w-4 h-4 text-cyan-400" />
                            <p className="text-[10px] font-mono text-slate-500 uppercase">System Load</p>
                            <p className="text-xl font-bold text-white">0.42%</p>
                          </div>
                          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                            <Database className="w-4 h-4 text-purple-400" />
                            <p className="text-[10px] font-mono text-slate-500 uppercase">DB Status</p>
                            <p className="text-xl font-bold text-white">OPTIMIZED</p>
                          </div>
                          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                            <Server className="w-4 h-4 text-green-400" />
                            <p className="text-[10px] font-mono text-slate-500 uppercase">Core Sync</p>
                            <p className="text-xl font-bold text-white">STABLE</p>
                          </div>
                          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                            <ShieldCheck className="w-4 h-4 text-blue-400" />
                            <p className="text-[10px] font-mono text-slate-500 uppercase">Security</p>
                            <p className="text-xl font-bold text-white">MAXIMUM</p>
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                          <label className="text-[10px] font-mono text-slate-500 uppercase mb-3 block">Admin Commands</label>
                          <div className="space-y-2">
                            <button 
                              onClick={() => {
                                if (confirm('Are you sure you want to clear all conversation memory? This cannot be undone.')) {
                                  clearMemory();
                                }
                              }}
                              className="w-full py-2 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-left text-slate-300 transition-colors flex items-center justify-between"
                            >
                              <span>Flush System Memory</span>
                              <Database className="w-3 h-3 opacity-50" />
                            </button>
                            <button className="w-full py-2 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-left text-slate-300 transition-colors flex items-center justify-between">
                              <span>Reboot Neural Core</span>
                              <Terminal className="w-3 h-3 opacity-50" />
                            </button>
                            <button className="w-full py-2 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-left text-slate-300 transition-colors flex items-center justify-between">
                              <span>Flush System Cache</span>
                              <Terminal className="w-3 h-3 opacity-50" />
                            </button>
                            <button className="w-full py-2 px-4 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-xs text-left text-red-400 transition-colors flex items-center justify-between">
                              <span>Emergency Shutdown</span>
                              <Terminal className="w-3 h-3 opacity-50" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-mono text-slate-500 uppercase block">System Runtime Logs</label>
                          <button 
                            onClick={() => addLog('info', 'System logs cleared manually')}
                            className="text-[10px] font-mono text-red-500 hover:text-red-400 uppercase"
                          >
                            Clear Logs
                          </button>
                        </div>
                        <div className="space-y-2 font-mono text-[10px]">
                          {systemLogs.length === 0 ? (
                            <p className="text-slate-600 italic py-4 text-center">No system events recorded.</p>
                          ) : (
                            systemLogs.map((log, i) => (
                              <div key={i} className={cn(
                                "p-2 rounded border border-white/5 bg-black/40",
                                log.type === 'error' ? "border-red-500/20 text-red-400" : 
                                log.type === 'warning' ? "border-yellow-500/20 text-yellow-400" : "text-slate-400"
                              )}>
                                <div className="flex justify-between mb-1 opacity-50">
                                  <span>[{log.timestamp.split('T')[1].split('.')[0]}] {log.type.toUpperCase()}</span>
                                </div>
                                <p className="break-words">{log.message}</p>
                                {log.details && (
                                  <pre className="mt-1 p-1 bg-black/20 rounded text-[8px] overflow-x-auto">
                                    {JSON.stringify(log.details, null, 2)}
                                  </pre>
                                )}
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-8 space-y-6">
                    <div className="w-16 h-16 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto border border-cyan-500/20">
                      <ShieldCheck className="w-8 h-8 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Authentication Required</h3>
                      <p className="text-xs text-slate-500 mt-1">Sign in to persist your contacts and preferences.</p>
                    </div>
                    
                    <form onSubmit={handleEmailLogin} className="space-y-4 text-left">
                      <div>
                        <label className="text-[10px] font-mono text-slate-500 uppercase mb-1 block">Email Address</label>
                        <input 
                          type="email" 
                          placeholder="admin@example.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-500 uppercase mb-1 block">Password</label>
                        <input 
                          type="password" 
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500/50"
                          required
                        />
                      </div>
                      {loginError && <p className="text-[10px] text-red-500 font-mono">{loginError}</p>}
                      <button 
                        type="submit"
                        disabled={isLoggingIn}
                        className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isLoggingIn ? 'Authenticating...' : 'Sign In with Email'}
                      </button>
                    </form>

                    <div className="relative">
                      <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
                      <div className="relative flex justify-center text-[10px] uppercase font-mono"><span className="bg-[#0a0a0a] px-2 text-slate-500">Or</span></div>
                    </div>

                    <button 
                      onClick={login}
                      className="w-full py-3 bg-white text-black hover:bg-slate-200 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2"
                    >
                      <img src="https://www.google.com/favicon.ico" alt="" className="w-4 h-4" />
                      Continue with Google
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer Status Bar */}
      <footer className="relative z-10 h-8 bg-cyan-950/20 border-t border-white/5 flex items-center px-6 justify-between text-[9px] font-mono text-slate-500">
        <div className="flex items-center gap-4">
          <span>CPU: 12%</span>
          <span>MEM: 1.4GB</span>
          <span className="text-cyan-800">|</span>
          <span>UPTIME: 04:22:15</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <div className="w-1 h-1 rounded-full bg-cyan-500" />
            VOICE_ENGINE_READY
          </span>
          <span className="flex items-center gap-1">
            <div className="w-1 h-1 rounded-full bg-cyan-500" />
            NEURAL_LINK_SYNCED
          </span>
        </div>
      </footer>

      {/* Voice Chat Overlay */}
      <AnimatePresence>
        {showVoiceChat && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100]"
          >
            <VoiceChat isDarkMode={isDarkMode} onClose={() => setShowVoiceChat(false)} status={status} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video Call Overlay */}
      <AnimatePresence>
        {videoCall.active && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center"
          >
            {/* Remote Video (Simulated) */}
            <div className="absolute inset-0 overflow-hidden">
              {videoCall.status === 'connected' ? (
                <img 
                  src={`https://picsum.photos/seed/${videoCall.from}/1920/1080`} 
                  alt="Remote User" 
                  className="w-full h-full object-cover opacity-60"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4 animate-pulse">
                    <User className="w-12 h-12 text-cyan-400" />
                  </div>
                  <p className="text-xl font-bold text-white tracking-widest uppercase">
                    {videoCall.status === 'ringing' ? 'Incoming Call' : 'Calling...'}
                  </p>
                  <p className="text-cyan-400 font-mono mt-2">{videoCall.from}</p>
                </div>
              )}
            </div>

            {/* Local Video Preview */}
            {videoCall.stream && (
              <motion.div 
                drag
                dragConstraints={{ left: -200, right: 200, top: -300, bottom: 300 }}
                className="absolute top-8 right-8 w-32 md:w-48 aspect-[3/4] bg-black rounded-2xl border-2 border-white/20 overflow-hidden shadow-2xl z-10 cursor-move"
              >
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline 
                  muted 
                  className="w-full h-full object-cover scale-x-[-1]"
                />
              </motion.div>
            )}

            {/* Call Controls */}
            <div className="relative z-20 mt-auto mb-12 flex flex-col items-center gap-8">
              {videoCall.status === 'ringing' ? (
                <div className="flex gap-12">
                  <button 
                    onClick={endVideoCall}
                    className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white shadow-lg shadow-red-500/40 hover:bg-red-600 transition-all active:scale-90"
                  >
                    <PhoneOff className="w-8 h-8" />
                  </button>
                  <button 
                    onClick={acceptVideoCall}
                    className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white shadow-lg shadow-green-500/40 hover:bg-green-600 transition-all animate-bounce active:scale-90"
                  >
                    <PhoneCall className="w-8 h-8" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-6 p-4 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/10">
                  <button className="p-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-colors">
                    <MicOff className="w-6 h-6" />
                  </button>
                  <button className="p-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white transition-colors">
                    <VideoOff className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={endVideoCall}
                    className="p-4 rounded-2xl bg-red-500 hover:bg-red-600 text-white transition-colors shadow-lg shadow-red-500/20"
                  >
                    <PhoneOff className="w-6 h-6" />
                  </button>
                </div>
              )}

              {videoCall.status === 'connected' && (
                <div className="text-center">
                  <p className="text-white font-medium">{videoCall.from}</p>
                  <p className="text-xs text-slate-400 font-mono mt-1">04:22 // SECURE_LINE</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
