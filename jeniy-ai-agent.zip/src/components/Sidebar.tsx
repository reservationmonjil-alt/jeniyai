import React from 'react';
import { Plus, MessageSquare, Trash2, Settings, User } from 'lucide-react';
import { cn } from '../lib/utils';

interface Chat {
  id: string;
  title: string;
}

interface SidebarProps {
  chats: Chat[];
  activeChatId: string;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  chats, activeChatId, onNewChat, onSelectChat, onDeleteChat, isDarkMode, toggleDarkMode 
}) => {
  return (
    <div className={cn("w-64 flex flex-col h-full p-4 border-r", isDarkMode ? "bg-gray-900 border-gray-800" : "bg-gray-50 border-gray-200")}>
      <button 
        onClick={onNewChat}
        className={cn("flex items-center gap-2 w-full p-3 rounded-lg mb-4 transition-colors", isDarkMode ? "bg-gray-800 hover:bg-gray-700 text-white" : "bg-white hover:bg-gray-100 text-gray-900 border border-gray-200")}
      >
        <Plus size={20} />
        New Chat
      </button>
      
      <div className="flex-1 overflow-y-auto space-y-2">
        {chats.map(chat => (
          <div 
            key={chat.id}
            onClick={() => onSelectChat(chat.id)}
            className={cn("flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors", 
              activeChatId === chat.id 
                ? (isDarkMode ? "bg-gray-800 text-white" : "bg-gray-200 text-gray-900")
                : (isDarkMode ? "text-gray-400 hover:bg-gray-800" : "text-gray-600 hover:bg-gray-200")
            )}
          >
            <div className="flex items-center gap-2 truncate">
              <MessageSquare size={16} />
              <span className="truncate">{chat.title}</span>
            </div>
            <button onClick={(e) => { e.stopPropagation(); onDeleteChat(chat.id); }} className="p-1 hover:text-red-500">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-700">
        <button onClick={toggleDarkMode} className="flex items-center gap-2 p-2 w-full rounded-lg hover:bg-gray-800">
          {isDarkMode ? "Light Mode" : "Dark Mode"}
        </button>
      </div>
    </div>
  );
};
