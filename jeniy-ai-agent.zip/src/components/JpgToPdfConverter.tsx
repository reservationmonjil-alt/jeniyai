import React, { useState } from 'react';
import { FileUp, FileText, X, Settings } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { cn } from '../lib/utils';

interface JpgToPdfConverterProps {
  isDarkMode: boolean;
}

export const JpgToPdfConverter: React.FC<JpgToPdfConverterProps> = ({ isDarkMode }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [quality, setQuality] = useState<'FAST' | 'MEDIUM' | 'SLOW'>('MEDIUM');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  const convertToPdf = () => {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const imgData = event.target?.result as string;
      const img = new Image();
      img.src = imgData;
      img.onload = () => {
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        
        const imgRatio = img.width / img.height;
        const pdfRatio = pdfWidth / pdfHeight;
        
        let width, height;
        if (imgRatio > pdfRatio) {
          width = pdfWidth;
          height = pdfWidth / imgRatio;
        } else {
          height = pdfHeight;
          width = pdfHeight * imgRatio;
        }
        
        const x = (pdfWidth - width) / 2;
        const y = (pdfHeight - height) / 2;
        
        pdf.addImage(imgData, 'JPEG', x, y, width, height, undefined, quality);
        pdf.save(`${file.name.split('.')[0]}.pdf`);
      };
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className={cn("flex flex-col items-center justify-center h-full p-6", isDarkMode ? "bg-gray-950 text-white" : "bg-white text-gray-900")}>
      <h2 className="text-2xl font-bold mb-6">JPG to PDF Converter</h2>
      
      {!file ? (
        <label className={cn("flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer", isDarkMode ? "border-gray-700 bg-gray-800 hover:bg-gray-700" : "border-gray-300 bg-gray-100 hover:bg-gray-200")}>
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <FileUp className="w-10 h-10 mb-3 text-gray-400" />
            <p className="mb-2 text-sm">Click to upload or drag and drop</p>
            <p className="text-xs text-gray-500">JPG/JPEG files only</p>
          </div>
          <input type="file" className="hidden" accept="image/jpeg, image/jpg" onChange={handleFileChange} />
        </label>
      ) : (
        <div className="flex flex-col items-center w-full max-w-md">
          <div className="relative w-full h-64 mb-4">
            <img src={preview!} alt="Preview" className="w-full h-full object-contain rounded-lg" />
            <button onClick={() => { setFile(null); setPreview(null); }} className="absolute top-2 right-2 p-1 bg-red-500 rounded-full text-white">
              <X size={16} />
            </button>
          </div>
          <div className="flex gap-4 mb-4">
            <label className="flex items-center gap-2">
              <Settings size={16} /> Quality:
            </label>
            <select value={quality} onChange={(e) => setQuality(e.target.value as any)} className={cn("p-2 rounded-lg", isDarkMode ? "bg-gray-800" : "bg-gray-100")}>
              <option value="FAST">Fast (Low)</option>
              <option value="MEDIUM">Medium</option>
              <option value="SLOW">Slow (High)</option>
            </select>
          </div>
          <button onClick={convertToPdf} className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <FileText size={20} />
            Convert to PDF
          </button>
        </div>
      )}
    </div>
  );
};
