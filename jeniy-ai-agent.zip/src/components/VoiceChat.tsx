import React, { useEffect, useRef } from 'react';
import { Mic, X, Volume2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface VoiceChatProps {
  isDarkMode: boolean;
  onClose: () => void;
  status: 'idle' | 'listening' | 'speaking' | 'processing';
}

export const VoiceChat: React.FC<VoiceChatProps> = ({ isDarkMode, onClose, status }) => {
  return (
    <div className={cn("fixed inset-0 z-50 flex flex-col items-center justify-center p-6", isDarkMode ? "bg-gray-950" : "bg-white")}>
      <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-full hover:bg-gray-700">
        <X size={24} />
      </button>
      
      <div className="flex flex-col items-center gap-8">
        <div className={cn(
          "w-32 h-32 rounded-full flex items-center justify-center animate-pulse",
          status === 'listening' ? "bg-blue-500" : status === 'speaking' ? "bg-green-500" : status === 'processing' ? "bg-yellow-500" : "bg-gray-700"
        )}>
          {status === 'listening' ? <Mic size={48} className="text-white" /> : status === 'processing' ? <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" /> : <Volume2 size={48} className="text-white" />}
        </div>
        <h2 className="text-2xl font-bold">
          {status === 'listening' ? "Listening..." : status === 'speaking' ? "Speaking..." : status === 'processing' ? "Thinking..." : "Ready"}
        </h2>
      </div>
    </div>
  );
};
