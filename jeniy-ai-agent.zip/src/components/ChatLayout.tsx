import React from 'react';
import { Sidebar } from './Sidebar';
import { ChatArea } from './ChatArea';
import { cn } from '../lib/utils';

interface ChatLayoutProps {
  messages: any[];
  onSendMessage: (text: string) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  chats: any[];
  activeChatId: string;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  onClearHistory: () => void;
}

export const ChatLayout: React.FC<ChatLayoutProps> = ({ 
  messages, onSendMessage, isDarkMode, toggleDarkMode, chats, activeChatId, onNewChat, onSelectChat, onDeleteChat, onClearHistory 
}) => {
  return (
    <div className={cn("flex h-screen w-full", isDarkMode ? "dark" : "")}>
      <Sidebar 
        chats={chats} 
        activeChatId={activeChatId} 
        onNewChat={onNewChat} 
        onSelectChat={onSelectChat} 
        onDeleteChat={onDeleteChat} 
        isDarkMode={isDarkMode} 
        toggleDarkMode={toggleDarkMode}
      />
      <div className="flex-1">
        <ChatArea messages={messages} onSendMessage={onSendMessage} isDarkMode={isDarkMode} onClearHistory={onClearHistory} />
      </div>
    </div>
  );
};
