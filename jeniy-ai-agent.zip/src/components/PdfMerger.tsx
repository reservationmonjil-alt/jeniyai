import React, { useState } from 'react';
import { FileUp, Trash2, Merge, GripVertical } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '../lib/utils';

interface PdfMergerProps {
  isDarkMode: boolean;
}

const SortablePdfItem = ({ file, onDelete }: { file: File; onDelete: () => void }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: file.name });
  const style = { transform: CSS.Transform.toString(transform), transition };

  return (
    <div ref={setNodeRef} style={style} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg border border-white/10 mb-2">
      <div {...attributes} {...listeners} className="cursor-grab">
        <GripVertical size={20} className="text-slate-500" />
      </div>
      <span className="flex-1 truncate">{file.name}</span>
      <button onClick={onDelete} className="text-red-500 hover:text-red-400">
        <Trash2 size={18} />
      </button>
    </div>
  );
};

export const PdfMerger: React.FC<PdfMergerProps> = ({ isDarkMode }) => {
  const [files, setFiles] = useState<File[]>([]);
  const sensors = useSensors(useSensor(PointerSensor), useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }));

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles([...files, ...Array.from(e.target.files)]);
    }
  };

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      setFiles((items) => {
        const oldIndex = items.findIndex((f) => f.name === active.id);
        const newIndex = items.findIndex((f) => f.name === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const mergePdfs = async () => {
    if (files.length < 2) return;

    const mergedPdf = await PDFDocument.create();
    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer);
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const mergedPdfBytes = await mergedPdf.save();
    const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'merged.pdf';
    a.click();
  };

  return (
    <div className={cn("flex flex-col h-full p-6", isDarkMode ? "bg-gray-950 text-white" : "bg-white text-gray-900")}>
      <h2 className="text-2xl font-bold mb-6">PDF Merger</h2>
      
      <label className={cn("flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer mb-6", isDarkMode ? "border-gray-700 bg-gray-800 hover:bg-gray-700" : "border-gray-300 bg-gray-100 hover:bg-gray-200")}>
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <FileUp className="w-8 h-8 mb-2 text-gray-400" />
          <p className="text-sm">Click to upload PDF files</p>
        </div>
        <input type="file" className="hidden" accept="application/pdf" multiple onChange={handleFileChange} />
      </label>

      <div className="flex-1 overflow-y-auto mb-6">
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={files.map(f => f.name)} strategy={verticalListSortingStrategy}>
            {files.map((file) => (
              <SortablePdfItem key={file.name} file={file} onDelete={() => setFiles(files.filter(f => f !== file))} />
            ))}
          </SortableContext>
        </DndContext>
      </div>

      <button 
        onClick={mergePdfs} 
        disabled={files.length < 2}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
      >
        <Merge size={20} />
        Merge PDFs
      </button>
    </div>
  );
};
