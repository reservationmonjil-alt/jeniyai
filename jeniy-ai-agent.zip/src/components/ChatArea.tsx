import React, { useRef, useEffect } from 'react';
import { Send, Copy, Check, Mic } from 'lucide-react';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface Message {
  id?: string;
  role: 'user' | 'ai';
  content: string;
  image?: string;
}

interface ChatAreaProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  isDarkMode: boolean;
  onClearHistory: () => void;
}

const CodeBlock = ({ language, value }: { language: string; value: string }) => {
  const [copied, setCopied] = React.useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group my-4 rounded-lg overflow-hidden bg-[#1e1e1e]">
      <div className="flex justify-between items-center px-4 py-2 bg-[#2d2d2d] text-gray-300 text-xs">
        <span>{language || 'text'}</span>
        <button onClick={copyToClipboard} className="flex items-center gap-1 hover:text-white">
          {copied ? <Check size={14} /> : <Copy size={14} />}
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      <SyntaxHighlighter
        language={language || 'text'}
        style={vscDarkPlus}
        customStyle={{ margin: 0, padding: '1rem' }}
      >
        {value}
      </SyntaxHighlighter>
    </div>
  );
};

const ChatMessage = ({ message, isDarkMode }: { message: Message; isDarkMode: boolean }) => {
  const [displayedContent, setDisplayedContent] = React.useState(message.role === 'user' ? message.content : '');

  useEffect(() => {
    if (message.role === 'ai') {
      let i = 0;
      setDisplayedContent(''); // Reset on message change
      const interval = setInterval(() => {
        setDisplayedContent(message.content.slice(0, i + 1));
        i++;
        if (i >= message.content.length) clearInterval(interval);
      }, 10);
      return () => clearInterval(interval);
    } else {
      setDisplayedContent(message.content);
    }
  }, [message.content, message.role]);

  return (
    <div className={cn("flex", message.role === 'user' ? 'justify-end' : 'justify-start')}>
      <div className={cn(
        "max-w-[85%] p-4 rounded-2xl",
        message.role === 'user' 
          ? (isDarkMode ? "bg-blue-600 text-white" : "bg-blue-500 text-white")
          : (isDarkMode ? "bg-gray-800 text-gray-200" : "bg-gray-200 text-gray-800")
      )}>
        <ReactMarkdown
          components={{
            code({ node, className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || '');
              const language = match ? match[1] : '';
              const value = String(children).replace(/\n$/, '');
              return match ? (
                <CodeBlock language={language} value={value} />
              ) : (
                <code className={cn("bg-gray-700 px-1 rounded", className)} {...props}>
                  {children}
                </code>
              );
            }
          }}
        >
          {displayedContent}
        </ReactMarkdown>
        {message.image && (
          <img src={message.image} alt="AI Content" className="mt-2 rounded-lg max-w-full" referrerPolicy="no-referrer" />
        )}
      </div>
    </div>
  );
};

export const ChatArea: React.FC<ChatAreaProps> = ({ messages, onSendMessage, isDarkMode, onClearHistory }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = React.useState('');

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    onSendMessage(input);
    setInput('');
  };

  return (
    <div className={cn("flex flex-col h-full", isDarkMode ? "bg-gray-950 text-white" : "bg-white text-gray-900")}>
      <div className="flex justify-between items-center p-4 border-b border-gray-800">
        <h2 className="text-sm font-semibold">Chat</h2>
        <button onClick={onClearHistory} className="text-xs text-red-500 hover:text-red-400">Clear History</button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg, i) => (
          <ChatMessage key={msg.id || i} message={msg} isDarkMode={isDarkMode} />
        ))}
      </div>
      
      <div className={cn("p-4 border-t", isDarkMode ? "border-gray-800" : "border-gray-200")}>
        <div className={cn("flex items-center gap-2 p-2 rounded-lg", isDarkMode ? "bg-gray-800" : "bg-gray-100")}>
          <button onClick={() => { /* Handle voice chat open */ }} className="p-2 rounded-full hover:bg-gray-700">
            <Mic size={20} />
          </button>
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="flex-1 bg-transparent outline-none p-2"
          />
          <button onClick={handleSend} className="p-2 rounded-full hover:bg-gray-700">
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};
