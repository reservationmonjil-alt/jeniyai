import React, { useState, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { cn } from '../lib/utils';
import { FileText, Download, Loader2 } from 'lucide-react';

// Set worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).href;

export const PdfToJpgConverter: React.FC<{ isDarkMode: boolean }> = ({ isDarkMode }) => {
  const [file, setFile] = useState<File | null>(null);
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setImages([]);
    }
  };

  const convertPdfToJpg = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const convertedImages: string[] = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2.0 }); // High quality scale
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (context) {
          await page.render({ canvasContext: context, viewport, canvas: canvas }).promise;
          convertedImages.push(canvas.toDataURL('image/jpeg', 1.0)); // High quality JPEG
        }
      }
      setImages(convertedImages);
    } catch (error) {
      console.error('Error converting PDF to JPEG:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <input type="file" accept="application/pdf" onChange={handleFileChange} className="hidden" id="pdf-upload" />
        <label htmlFor="pdf-upload" className={cn("flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer", isDarkMode ? "bg-gray-800 hover:bg-gray-700" : "bg-gray-200 hover:bg-gray-300")}>
          <FileText size={20} />
          {file ? file.name : "Select PDF"}
        </label>
        <button 
          onClick={convertPdfToJpg} 
          disabled={!file || loading}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : "Convert to JPEG"}
        </button>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mt-4">
        {images.map((img, index) => (
          <div key={index} className="relative group">
            <img src={img} alt={`Page ${index + 1}`} className="rounded-lg border border-white/10" />
            <a href={img} download={`page_${index + 1}.jpg`} className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
              <Download size={16} />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};
