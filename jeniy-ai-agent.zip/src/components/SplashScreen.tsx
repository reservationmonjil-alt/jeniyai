import { motion } from "motion/react";
import { ShieldCheck, Terminal, Cpu, Globe } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1, ease: "easeInOut" }}
      onAnimationComplete={onComplete}
      className="fixed inset-0 z-[200] bg-[#020202] flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background Grid & Glow */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:40px_40px]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan-500/5 rounded-full blur-[150px]" />

      {/* Scanning Line */}
      <motion.div 
        animate={{ top: ["0%", "100%"] }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent z-20 pointer-events-none shadow-[0_0_15px_rgba(6,182,212,0.3)]"
      />

      {/* Animated Globe Vibe */}
      <div className="relative mb-12">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="relative w-56 h-56 md:w-80 md:h-80"
        >
          {/* Outer Rings */}
          <div className="absolute inset-0 rounded-full border border-cyan-500/10 border-dashed" />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[-10px] rounded-full border border-cyan-500/5 border-dotted" 
          />
          
          {/* Inner Globe Wireframe (Simulated Earth Vibe) */}
          <div className="absolute inset-4 rounded-full border-2 border-cyan-500/10 flex items-center justify-center overflow-hidden">
            {/* Latitude Lines */}
            {[...Array(6)].map((_, i) => (
              <div 
                key={`lat-${i}`}
                className="absolute w-full h-[1px] bg-cyan-500/10"
                style={{ top: `${(i + 1) * 14.28}%` }}
              />
            ))}
            {/* Longitude Lines */}
            {[...Array(6)].map((_, i) => (
              <div 
                key={`long-${i}`}
                className="absolute h-full w-[1px] bg-cyan-500/10"
                style={{ left: `${(i + 1) * 14.28}%` }}
              />
            ))}
            
            {/* Pulsing Core Glow */}
            <div className="absolute inset-0 bg-radial-gradient(circle, rgba(6,182,212,0.1) 0%, transparent 70%)" />
          </div>

          {/* Core Icon */}
          <motion.div 
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="w-24 h-24 bg-cyan-500/10 rounded-3xl flex items-center justify-center border border-cyan-500/30 shadow-[0_0_60px_-10px_rgba(6,182,212,0.6)] backdrop-blur-sm">
              <ShieldCheck className="w-12 h-12 text-cyan-400" />
            </div>
          </motion.div>
        </motion.div>

        {/* Orbiting Particles / Satellites */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ rotate: 360 }}
            transition={{ duration: 4 + i * 1.5, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[-40px] pointer-events-none"
          >
            <div 
              className="w-1.5 h-1.5 bg-cyan-400 rounded-full blur-[0.5px] absolute shadow-[0_0_8px_rgba(34,211,238,0.8)]"
              style={{ 
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: 0.4 + Math.random() * 0.6
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Company Info */}
      <div className="text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white tracking-[0.2em] mb-2">
            MONVECT <span className="text-cyan-500">IT</span>
          </h1>
          <div className="h-[1px] w-32 bg-gradient-to-r from-transparent via-cyan-500 to-transparent mx-auto mb-4" />
          <p className="text-cyan-400/60 font-mono text-xs uppercase tracking-[0.4em] mb-8">
            Advanced Intelligence Systems
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex flex-col items-center gap-4"
        >
          <div className="flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
            <Cpu className="w-3 h-3 text-cyan-500" />
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              CEO: Freelancer Monjil
            </span>
          </div>

          <div className="flex items-center gap-6 mt-8">
            <div className="flex flex-col items-center gap-1">
              <div className="w-1 h-1 rounded-full bg-cyan-500 animate-ping" />
              <span className="text-[8px] font-mono text-slate-600">CORE_BOOT</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-1 h-1 rounded-full bg-cyan-500 animate-ping [animation-delay:0.2s]" />
              <span className="text-[8px] font-mono text-slate-600">NEURAL_SYNC</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-1 h-1 rounded-full bg-cyan-500 animate-ping [animation-delay:0.4s]" />
              <span className="text-[8px] font-mono text-slate-600">DATA_LINK</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Progress Bar */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-64 h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ duration: 3, ease: "easeInOut" }}
          className="h-full bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.8)]"
        />
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-6 text-[10px] font-mono text-slate-500 uppercase tracking-[0.3em]"
      >
        Initializing System...
      </motion.div>
    </motion.div>
  );
}
