import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";

interface VisualizerProps {
  isListening: boolean;
  isSpeaking: boolean;
  className?: string;
}

export default function Visualizer({ isListening, isSpeaking, className }: VisualizerProps) {
  return (
    <div className={cn("relative flex items-center justify-center w-64 h-64", className)}>
      {/* Outer Glow */}
      <motion.div
        animate={{
          scale: isListening || isSpeaking ? [1, 1.1, 1] : 1,
          opacity: isListening || isSpeaking ? [0.3, 0.6, 0.3] : 0.2,
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute inset-0 rounded-full bg-cyan-500/20 blur-3xl"
      />

      {/* Core Orb */}
      <motion.div
        animate={{
          scale: isSpeaking ? [1, 1.05, 1] : 1,
          boxShadow: isSpeaking 
            ? "0 0 40px 10px rgba(6, 182, 212, 0.5)" 
            : "0 0 20px 5px rgba(6, 182, 212, 0.2)",
        }}
        transition={{
          duration: 0.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className={cn(
          "relative w-32 h-32 rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center overflow-hidden border border-cyan-300/30",
          isListening && "animate-pulse"
        )}
      >
        {/* Inner Swirls */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"
        />
        
        {/* Voice Waves */}
        {(isListening || isSpeaking) && (
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <motion.div
                key={i}
                animate={{
                  height: isSpeaking ? [10, 40, 10] : [5, 15, 5],
                }}
                transition={{
                  duration: 0.4,
                  repeat: Infinity,
                  delay: i * 0.1,
                }}
                className="w-1 bg-white rounded-full"
              />
            ))}
          </div>
        )}
      </motion.div>

      {/* Orbiting Rings */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute w-48 h-48 border border-cyan-500/10 rounded-full"
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute w-56 h-56 border border-blue-500/5 rounded-full"
      />
    </div>
  );
}
